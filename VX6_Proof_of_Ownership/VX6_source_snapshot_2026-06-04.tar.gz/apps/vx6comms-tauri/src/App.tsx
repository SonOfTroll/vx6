import { invoke } from "@tauri-apps/api/core";
import { useMemo, useState } from "react";

type Contact = {
  id: string;
  nodeName: string;
  address: string;
  description: string;
  email: string;
  phone: string;
  approved: boolean;
};

type RequestItem = {
  id: string;
  nodeName: string;
  address: string;
  description: string;
  firstMessage: string;
  createdAt: string;
};

type ChatMessage = {
  id: string;
  fromSelf: boolean;
  text: string;
  status: "pending" | "sent" | "failed";
  at: string;
  ts: number;
};

type Group = {
  id: string;
  name: string;
  members: string[];
};

function nowStamp() {
  return new Date().toISOString();
}

export default function App() {
  const [nodeName, setNodeName] = useState("alice");
  const [status, setStatus] = useState("Idle");
  const [output, setOutput] = useState("No runtime output yet.");
  const [peerAddr, setPeerAddr] = useState("[::1]:4242");
  const [peerName, setPeerName] = useState("bob");
  const [peerDescription, setPeerDescription] = useState("Friend from office");
  const [peerEmail, setPeerEmail] = useState("");
  const [peerPhone, setPeerPhone] = useState("");
  const [requestFirstMessage, setRequestFirstMessage] = useState("Hi, let's connect on VX6.");
  const [inviteInput, setInviteInput] = useState("");
  const [inviteOutput, setInviteOutput] = useState("");
  const [serviceName, setServiceName] = useState("web");
  const [serviceTarget, setServiceTarget] = useState("127.0.0.1:8080");
  const [connectService, setConnectService] = useState("bob.web");
  const [connectListen, setConnectListen] = useState("127.0.0.1:9000");
  const [selectedTarget, setSelectedTarget] = useState("peer:bob");
  const [chatInput, setChatInput] = useState("");
  const [contacts, setContacts] = useState<Record<string, Contact>>({
    bob: {
      id: "bob",
      nodeName: "bob",
      address: "[::1]:4242",
      description: "Default contact",
      email: "",
      phone: "",
      approved: true,
    },
  });
  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({
    "peer:bob": [],
  });
  const [groups, setGroups] = useState<Record<string, Group>>({});
  const [groupName, setGroupName] = useState("team");
  const [groupMembersRaw, setGroupMembersRaw] = useState("bob");
  const [search, setSearch] = useState("");

  async function runStatus() {
    setStatus("Checking node status...");
    try {
      const out = await invoke<string>("vx6_status");
      setOutput(out);
      setStatus("Node status updated");
    } catch (err) {
      setStatus("Status request failed");
      setOutput(String(err));
    }
  }

  async function initNode() {
    setStatus("Initializing node...");
    try {
      const out = peerAddr.trim()
        ? await invoke<string>("vx6_init_with_peer", { name: nodeName, peer: peerAddr })
        : await invoke<string>("vx6_init", { name: nodeName });
      setOutput(out);
      setStatus("Node initialized");
    } catch (err) {
      setStatus("Initialization failed");
      setOutput(String(err));
    }
  }

  async function startNode() {
    setStatus("Starting node...");
    try {
      const out = await invoke<string>("vx6_node_start");
      setOutput(out);
      setStatus("Node running");
    } catch (err) {
      setStatus("Start failed");
      setOutput(String(err));
    }
  }

  async function stopNode() {
    setStatus("Stopping node...");
    try {
      const out = await invoke<string>("vx6_node_stop");
      setOutput(out);
      setStatus("Node stopped");
    } catch (err) {
      setStatus("Stop failed");
      setOutput(String(err));
    }
  }

  async function exec(args: string[], label: string) {
    setStatus(label);
    try {
      const out = await invoke<string>("vx6_exec", { args });
      setOutput(out);
      setStatus(`${label} complete`);
    } catch (err) {
      setStatus(`${label} failed`);
      setOutput(String(err));
    }
  }

  function upsertChat(target: string) {
    setMessages((prev) => (prev[target] ? prev : { ...prev, [target]: [] }));
  }

  async function createContactRequest() {
    if (!peerName.trim() || !peerAddr.trim()) return;
    const req: RequestItem = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      nodeName: peerName.trim(),
      address: peerAddr.trim(),
      description: peerDescription.trim(),
      firstMessage: requestFirstMessage.trim(),
      createdAt: nowStamp(),
    };
    setRequests((prev) => [req, ...prev]);
    setStatus("Request added to approval queue");
  }

  async function approveRequest(req: RequestItem) {
    await exec(["peer", "add", "--addr", req.address, "--name", req.nodeName], "Approve contact");
    const newContact: Contact = {
      id: req.nodeName,
      nodeName: req.nodeName,
      address: req.address,
      description: req.description,
      email: peerEmail.trim(),
      phone: peerPhone.trim(),
      approved: true,
    };
    setContacts((prev) => ({ ...prev, [req.nodeName]: newContact }));
    const target = `peer:${req.nodeName}`;
    upsertChat(target);
    setSelectedTarget(target);
    setRequests((prev) => prev.filter((x) => x.id !== req.id));
    setConnectService(`${req.nodeName}.${serviceName}`);
  }

  function rejectRequest(id: string) {
    setRequests((prev) => prev.filter((x) => x.id !== id));
  }

  function generateInvite() {
    const payload = {
      nodeName: nodeName.trim(),
      addr: peerAddr.trim(),
      desc: peerDescription.trim(),
      email: peerEmail.trim(),
      phone: peerPhone.trim(),
      ts: nowStamp(),
    };
    const link = `vx6chat://invite/${btoa(JSON.stringify(payload))}`;
    setInviteOutput(link);
  }

  async function consumeInvite() {
    const raw = inviteInput.trim();
    if (!raw.startsWith("vx6chat://invite/")) {
      setStatus("Invalid invite link");
      return;
    }
    try {
      const encoded = raw.replace("vx6chat://invite/", "");
      const data = JSON.parse(atob(encoded)) as {
        nodeName: string;
        addr: string;
        desc?: string;
        email?: string;
        phone?: string;
      };
      setPeerName(data.nodeName || "");
      setPeerAddr(data.addr || "");
      setPeerDescription(data.desc || "");
      setPeerEmail(data.email || "");
      setPeerPhone(data.phone || "");
      await createContactRequest();
      setStatus("Invite converted to request");
    } catch (err) {
      setStatus("Failed to parse invite");
      setOutput(String(err));
    }
  }

  async function sendMessage() {
    const text = chatInput.trim();
    if (!text || !selectedTarget.trim()) return;
    const isPeer = selectedTarget.startsWith("peer:");
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const stamp = new Date();
    const msg: ChatMessage = {
      id,
      fromSelf: true,
      text,
      status: "pending",
      at: stamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      ts: stamp.getTime(),
    };
    setMessages((prev) => ({
      ...prev,
      [selectedTarget]: [...(prev[selectedTarget] || []), msg].sort((a, b) => a.ts - b.ts),
    }));
    setChatInput("");
    if (!isPeer) {
      setMessages((prev) => ({
        ...prev,
        [selectedTarget]: (prev[selectedTarget] || []).map((m) =>
          m.id === id ? { ...m, status: "sent" } : m,
        ),
      }));
      setStatus("Group message synced by timestamp ordering");
      return;
    }
    const peer = selectedTarget.replace("peer:", "");
    if (!contacts[peer]?.approved) {
      setStatus("Contact is not approved yet");
      setMessages((prev) => ({
        ...prev,
        [selectedTarget]: (prev[selectedTarget] || []).map((m) =>
          m.id === id ? { ...m, status: "failed" } : m,
        ),
      }));
      return;
    }
    try {
      const out = await invoke<string>("vx6_send_text", { to: peer, text });
      setOutput(out);
      setStatus(`Message delivered to ${peer}`);
      setMessages((prev) => ({
        ...prev,
        [selectedTarget]: (prev[selectedTarget] || []).map((m) =>
          m.id === id ? { ...m, status: "sent" } : m,
        ),
      }));
    } catch (err) {
      setOutput(String(err));
      setStatus(`Message failed for ${peer}`);
      setMessages((prev) => ({
        ...prev,
        [selectedTarget]: (prev[selectedTarget] || []).map((m) =>
          m.id === id ? { ...m, status: "failed" } : m,
        ),
      }));
    }
  }

  function createGroup() {
    const members = groupMembersRaw
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean);
    if (!groupName.trim() || members.length === 0) return;
    const id = `group:${groupName.trim()}`;
    const grp: Group = { id, name: groupName.trim(), members };
    setGroups((prev) => ({ ...prev, [id]: grp }));
    upsertChat(id);
    setSelectedTarget(id);
    setStatus(`Group ${grp.name} created`);
  }

  const peerTargets = useMemo(
    () =>
      Object.values(contacts)
        .filter((c) => c.approved)
        .map((c) => ({ id: `peer:${c.id}`, title: c.nodeName, meta: c.description || "approved contact" })),
    [contacts],
  );
  const groupTargets = useMemo(
    () =>
      Object.values(groups).map((g) => ({
        id: g.id,
        title: `# ${g.name}`,
        meta: `${g.members.length} members`,
      })),
    [groups],
  );
  const allTargets = useMemo(() => [...peerTargets, ...groupTargets], [peerTargets, groupTargets]);
  const filteredTargets = useMemo(
    () => allTargets.filter((t) => t.title.toLowerCase().includes(search.toLowerCase())),
    [allTargets, search],
  );
  const activeMessages = messages[selectedTarget] || [];

  return (
    <main className="messenger">
      <aside className="leftPane">
        <header className="brand">
          <h1>VX6 Comms</h1>
          <span>{status}</span>
        </header>
        <input className="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search contacts/groups" />
        <div className="peerList">
          {filteredTargets.map((target) => (
            <button
              key={target.id}
              className={`peerItem${target.id === selectedTarget ? " active" : ""}`}
              onClick={() => setSelectedTarget(target.id)}
            >
              <span className="peerName">{target.title}</span>
              <span className="peerMeta">{target.meta}</span>
            </button>
          ))}
        </div>
        <section className="card small">
          <h3>DHT + Contact List</h3>
          <div className="row">
            <button className="ghost" onClick={() => exec(["debug", "dht-status"], "DHT status")}>DHT Status</button>
            <button className="ghost" onClick={() => exec(["peer"], "List peers")}>My Contacts</button>
          </div>
        </section>
      </aside>

      <section className="chatPane">
        <header className="chatHeader">
          <h2>{selectedTarget.startsWith("group:") ? selectedTarget : selectedTarget.replace("peer:", "")}</h2>
          <div className="chatActions">
            <button className="ghost" onClick={() => exec(["receive", "status"], "Receive status")}>Receive</button>
            <button className="ghost" onClick={() => exec(["list"], "Network list")}>Lookup</button>
          </div>
        </header>
        <div className="timeline">
          {activeMessages.length === 0 ? (
            <div className="empty">No messages yet.</div>
          ) : (
            activeMessages.map((m) => (
              <div key={m.id} className={`bubbleWrap ${m.fromSelf ? "self" : ""}`}>
                <div className="bubble">
                  <p>{m.text}</p>
                  <small>{m.at} · {m.status}</small>
                </div>
              </div>
            ))
          )}
        </div>
        <footer className="composer">
          <textarea value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Write a message" rows={2} />
          <button onClick={sendMessage}>Send</button>
        </footer>
      </section>

      <aside className="rightPane">
        <section className="card">
          <h3>Node Setup</h3>
          <label htmlFor="name">Node name</label>
          <input id="name" value={nodeName} onChange={(e) => setNodeName(e.target.value)} />
          <label htmlFor="peer">Seed peer</label>
          <input id="peer" value={peerAddr} onChange={(e) => setPeerAddr(e.target.value)} />
          <div className="row">
            <button onClick={initNode}>Init</button>
            <button onClick={startNode}>Start</button>
            <button className="ghost" onClick={stopNode}>Stop</button>
          </div>
          <div className="row">
            <button className="ghost" onClick={runStatus}>Status</button>
            <button className="ghost" onClick={() => exec(["identity"], "Identity")}>Identity</button>
          </div>
        </section>

        <section className="card">
          <h3>Approval Queue</h3>
          {requests.length === 0 ? <p className="muted">No pending requests</p> : null}
          {requests.map((r) => (
            <div key={r.id} className="requestRow">
              <strong>{r.nodeName}</strong>
              <span>{r.address}</span>
              <span>{r.description || "No description"}</span>
              <span>First message: {r.firstMessage}</span>
              <small>{r.createdAt}</small>
              <div className="row">
                <button onClick={() => approveRequest(r)}>Approve</button>
                <button className="ghost" onClick={() => rejectRequest(r.id)}>Reject</button>
              </div>
            </div>
          ))}
        </section>

        <section className="card">
          <h3>New Contact Request (Metadata)</h3>
          <label>Node name</label>
          <input value={peerName} onChange={(e) => setPeerName(e.target.value)} />
          <label>Address</label>
          <input value={peerAddr} onChange={(e) => setPeerAddr(e.target.value)} />
          <label>Description</label>
          <input value={peerDescription} onChange={(e) => setPeerDescription(e.target.value)} />
          <label>Email</label>
          <input value={peerEmail} onChange={(e) => setPeerEmail(e.target.value)} />
          <label>Phone</label>
          <input value={peerPhone} onChange={(e) => setPeerPhone(e.target.value)} />
          <label>First message for approval</label>
          <input value={requestFirstMessage} onChange={(e) => setRequestFirstMessage(e.target.value)} />
          <div className="row">
            <button onClick={createContactRequest}>Queue Request</button>
            <button className="ghost" onClick={() => exec(["peer"], "List peers")}>Refresh</button>
          </div>
        </section>

        <section className="card">
          <h3>Invite Link</h3>
          <div className="row">
            <button onClick={generateInvite}>Generate Link</button>
            <button className="ghost" onClick={consumeInvite}>Paste + Queue</button>
          </div>
          <label>My invite link</label>
          <textarea rows={3} value={inviteOutput} onChange={(e) => setInviteOutput(e.target.value)} />
          <label>Paste invite</label>
          <textarea rows={3} value={inviteInput} onChange={(e) => setInviteInput(e.target.value)} />
        </section>

        <section className="card">
          <h3>Group Chat</h3>
          <label>Group name</label>
          <input value={groupName} onChange={(e) => setGroupName(e.target.value)} />
          <label>Members (comma-separated)</label>
          <input value={groupMembersRaw} onChange={(e) => setGroupMembersRaw(e.target.value)} />
          <button onClick={createGroup}>Create Group</button>
          <p className="muted">Group and direct messages are ordered by precise timestamp for sync behavior.</p>
        </section>

        <section className="card">
          <h3>Service Actions</h3>
          <label htmlFor="svcname">Service name</label>
          <input id="svcname" value={serviceName} onChange={(e) => setServiceName(e.target.value)} />
          <label htmlFor="svctarget">Service target</label>
          <input id="svctarget" value={serviceTarget} onChange={(e) => setServiceTarget(e.target.value)} />
          <div className="row">
            <button onClick={() => exec(["service", "add", "--name", serviceName, "--target", serviceTarget], "Service add")}>Add</button>
            <button className="ghost" onClick={() => exec(["service", "remove", "--name", serviceName], "Service remove")}>Remove</button>
          </div>
          <label htmlFor="connectsvc">Connect service</label>
          <input id="connectsvc" value={connectService} onChange={(e) => setConnectService(e.target.value)} />
          <label htmlFor="connectlisten">Local listen</label>
          <input id="connectlisten" value={connectListen} onChange={(e) => setConnectListen(e.target.value)} />
          <div className="row">
            <button onClick={() => exec(["connect", "--service", connectService, "--listen", connectListen], "Connect service")}>Connect</button>
          </div>
        </section>

        <section className="card logs">
          <h3>Runtime Output</h3>
          <pre>{output}</pre>
        </section>
      </aside>
    </main>
  );
}
