#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use once_cell::sync::Lazy;
use std::fs;
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

static NODE_PROCESS: Lazy<Mutex<Option<Child>>> = Lazy::new(|| Mutex::new(None));

#[tauri::command]
fn vx6_status() -> Result<String, String> {
    run_vx6(&["status"])
}

#[tauri::command]
fn vx6_init(name: String) -> Result<String, String> {
    run_vx6(&["init", "--name", &name, "--listen", "[::]:4242"])
}

#[tauri::command]
fn vx6_init_with_peer(name: String, peer: String) -> Result<String, String> {
    let primary = run_vx6(&[
        "init",
        "--name",
        &name,
        "--listen",
        "[::]:4242",
        "--peer",
        &peer,
    ]);
    match primary {
        Ok(out) => Ok(out),
        Err(err) => {
            if err.contains("flag provided but not defined") || err.contains("--peer") {
                let mut out = run_vx6(&["init", "--name", &name, "--listen", "[::]:4242"])?;
                let peer_out = run_vx6(&["peer", "add", "--addr", &peer])?;
                out.push_str("\n[compat fallback] peer added with `vx6 peer add`\n");
                out.push_str(&peer_out);
                Ok(out)
            } else {
                Err(err)
            }
        }
    }
}

#[tauri::command]
fn vx6_node_start() -> Result<String, String> {
    let mut guard = NODE_PROCESS
        .lock()
        .map_err(|_| "failed to lock node process state".to_string())?;
    if guard.is_some() {
        return Ok("node already running in this app session".to_string());
    }
    let child = Command::new("vx6")
        .arg("node")
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("failed to start node: {e}"))?;
    let pid = child.id();
    *guard = Some(child);
    Ok(format!("node started (pid={pid})"))
}

#[tauri::command]
fn vx6_node_stop() -> Result<String, String> {
    let mut guard = NODE_PROCESS
        .lock()
        .map_err(|_| "failed to lock node process state".to_string())?;
    if let Some(mut child) = guard.take() {
        child
            .kill()
            .map_err(|e| format!("failed to stop node process: {e}"))?;
        return Ok("node stopped".to_string());
    }
    Ok("no in-app node process to stop".to_string())
}

#[tauri::command]
fn vx6_exec(args: Vec<String>) -> Result<String, String> {
    let owned: Vec<&str> = args.iter().map(String::as_str).collect();
    run_vx6(&owned)
}

#[tauri::command]
fn vx6_send_text(to: String, text: String) -> Result<String, String> {
    let payload = format!(
        "VX6-MSG\nfrom=tauri-ui\ncreated_at={}\n\n{}",
        current_unix(),
        text
    );
    let path = std::env::temp_dir().join(format!(
        "vx6-msg-{}-{}.txt",
        sanitize_for_file(&to),
        current_unix_nanos()
    ));
    fs::write(&path, payload).map_err(|e| format!("failed to write temp message file: {e}"))?;
    let path_s = path.to_string_lossy().to_string();
    let send_res = run_vx6(&["send", "--file", &path_s, "--to", &to]);
    let _ = fs::remove_file(&path);
    send_res
}

fn sanitize_for_file(v: &str) -> String {
    v.chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '-' || c == '_' {
                c
            } else {
                '_'
            }
        })
        .collect()
}

fn current_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn current_unix_nanos() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos()
}

fn run_vx6(args: &[&str]) -> Result<String, String> {
    let out = Command::new("vx6")
        .args(args)
        .output()
        .map_err(|e| format!("failed to run vx6: {e}"))?;
    let stdout = String::from_utf8_lossy(&out.stdout).to_string();
    let stderr = String::from_utf8_lossy(&out.stderr).to_string();
    if out.status.success() {
        Ok(stdout)
    } else {
        Err(format!("{stdout}\n{stderr}"))
    }
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .invoke_handler(tauri::generate_handler![
            vx6_status,
            vx6_init,
            vx6_init_with_peer,
            vx6_node_start,
            vx6_node_stop,
            vx6_exec,
            vx6_send_text
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
